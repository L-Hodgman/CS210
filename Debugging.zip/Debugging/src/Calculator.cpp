/*
 * Calculator.cpp
 *
 *  Date: 9/4/2020
 *  Author: Elizabeth Hodgman
 */

#include <iostream>
using namespace std;

int main()
{
	char statement[100];
	int op1; // In original, op1 and op2 were on the same line
	int op2; // Variables on the same line is not an error, but more understandable on separate lines
	char operation;
	char answer = 'Y';

	// Added entering text so user would know what characters to input
	cout << "Do you want to enter an expression?" << endl;
	cout << "Enter Y or N" << endl;
	cin >> answer;

	// Added while loop for invalid answer inputs
	// If user inputs anything other than Y(y) or N(n) program will loop back and ask again
	while ((answer != 'N') && (answer != 'n') && (answer != 'Y') && (answer != 'y')){
	    cout << "Invalid answer" << endl;
	    cout << "Enter Y or N" << endl;
	    cin >> answer;
	}

	// In original code, would only loop if input was 'y'
	// Added 'Y' that way if user inputs Y or y program will run
	while ((answer == 'Y') || (answer == 'y'))
	{
	    cout << "Enter expression" << endl;
	    cin >> op1 >> operation >> op2; // Original code had cin >> op2 >> operation >> op1
	                                    // Causing incorrect answers fyor the - and / operators (Input: 10(op1)-5(op2) Executed: 5(op2)-10(op1))

	    // All if statements had no brackets - without them all expressions would be outputted
	    if (operation == '+'){ // Had semicolon instead of brackets
	        cout << op1 << " + " << op2 << " = " << (op1 + op2) << endl; // Original code had arrows pointing in wrong direction (op2 >> " = ")
	    }
	    if (operation == '-'){ // Had semicolon instead of brackets
	        cout << op1 << " - " << op2 << " = " << (op1 - op2) << endl; // Original code had arrows pointing in wrong direction (cout >> op1)
	    }
	    if (operation == '*'){ // Original code had no brackets
	        cout << op1 << " * " << op2 << " = " << (op1 * op2) << endl; // Division operator was in original code output (5 / 10 = 50)
	    }
	    if (operation == '/'){ // Original code had no brackets
	        cout << op1 << " / " << op2 << " = " << (op1 / op2) << endl; // Multiplication operator was in original code output (10 * 5 = 2)
	    }

	    cout << "Do you wish to evaluate another expression? " << endl;
	    cin >> answer;

	    // Added second while loop to ensure valid input
	    while ((answer != 'N') && (answer != 'n') && (answer != 'Y') && (answer != 'y')){
	    	    cout << "Invalid answer" << endl;
	    	    cout << "Enter Y or N" << endl;
	    	    cin >> answer;
	    	}

	}

	// No loop was in the original code for N(n) input
	while ((answer == 'N') || (answer == 'n'))
	{
	    cout << "Goodbye";
	    return 0;
	}

}




