/*
 * WorkingClock.cpp
 *
 *  Created on: Sep 10, 2020
 *      Author: Elizabeth Hodgman
 */

#include <iomanip>
#include <iostream>
#include <windows.h>
#include <stdlib.h>

using namespace std;

// Public class Clock made for variables that are used universally within program
class Clock{
public:

	int hour;
	int minute;
	int second;

};

// Class to run the 12 hour clock
// Uses class Clock's variables for methods
// Public so methods can be called outside of class
class _12HourClock : public Clock{
public:

// Initiates _12HourClock variables using Clock class
_12HourClock(int Hour, int Minute, int Second){
	hour = Hour;
	minute = Minute;
	second = Second;
}

// Method to add a hour to the 12 hour clock
void AddOneHour() {
	// If the hour is 24 it will turn to 1
	if (hour == 24){
		hour = 1;
	}
	else{
		hour += 1;
	}
}

// Method to add a minute to the 12 hour clock
void AddOneMinute(){
	// If the minutes are at 59, minutes will turn to 0, then an hour will be added
	if (minute == 59){
		minute = 0;
		AddOneHour();
	}
	else{
		minute += 1;
	}
}

// Method to add a second to the 12 hour clock
void AddOneSecond(){
	// If the seconds are at 59, seconds will turn to 0, then a minute will be added
	if (second == 59){
		second = 0;
	    AddOneMinute();
	}
	else {
		second += 1;
	}
}
};

// Class to run the 24 hour clock
// Uses Clock's variables for methods
// Public so methods can be used outside of class
class _24HourClock : public Clock {
public:

// Initiates _24HourClock variables using Clock class
_24HourClock(int Hour, int Minute, int Second){
	hour = Hour;
	minute = Minute;
	second = Second;
}

// Method to add a hour to the 24 hour clock
void AddOneHour() {
	// If the hour is 24 it will turn to 1
	if (hour == 24){
		hour = 1;
	}
	else{
		hour += 1;
	}
}

// Method to add a minute to the 24 hour clock
void AddOneMinute(){
	// If the minutes are at 59, minutes will turn to 0, then an hour will be added
	if (minute == 59){
		minute = 0;
		AddOneHour();
	}
	else {
		minute += 1;
	}
}

// Method to add a second to the 24 hour clock
void AddOneSecond(){
	// If the seconds are at 59, seconds will turn to 0, then a minute will be added
	if (second == 59){
		second = 0;
		AddOneMinute();
	}
	else {
		second += 1;
	}
}
};

// Method to display clocks
// Using clock12 and clock24 to call _12HourClock and _24HourClock classes
void ClockDisplay(_12HourClock& clock12, _24HourClock& clock24){

	system("CLS");
	cout << endl;
	cout << "**************************     **************************" << endl; // Clock border
	cout << "*     12-Hour Clock      *     *      24-Hour Clock     *" << endl; // Clock border
	cout << "*      "; // Clock border

	// Printing 12 hour clock
	// Output example 00:00:00 AM

	// If the 12 hour clock hours are more than 12 will subtract 12 (e.g. 13 is 1)
	if(clock12.hour > 12){
		clock12.hour -= 12;
	}
	// If hours, minutes, or seconds are less than ten, will have 0 first (e.g. 3 outputs 03)
	// If more than 10, number will output as is
	if(clock12.hour < 10){
		cout << setfill('0') << setw(2) << clock12.hour << ":";
	}
	else{
		cout << clock12.hour << ":";
	}
	if(clock12.minute < 10){
		cout << setfill('0') << setw(2) << clock12.minute << ":";
	}
	else{
		cout << clock12.minute << ":";
	}
	if(clock12.second < 10){
		cout << setfill('0') << setw(2) << clock12.second;
	}
	else{
		 cout << clock12.second;
	}
	// Determining if time is AM or PM
	// If 24 hour clock is less 12(noon) or equals to 24(midnight) than AM
	if((clock24.hour < 12) || (clock24.hour == 24)){
		cout << " AM";
	}
	else{
		cout << " PM";
	}

	cout << "       *     *        "; // Clock border

	// Printing 24 hour clock
	// Output example 00:00:00

	// If hours, minutes, or seconds are less than ten, will have 0 first (e.g. 3 outputs 03)
	// If more than 10, number will output as is
	if(clock24.hour < 10){
		cout << setfill('0') << setw(2) << clock12.hour << ":";
	}
	else{
		cout << clock24.hour << ":";
	}
	if(clock24.minute < 10){
		cout << setfill('0') << setw(2) << clock12.minute << ":";
	}
	else{
		cout << clock24.minute << ":";
	}
	if(clock24.second < 10){
		cout << setfill('0') << setw(2) << clock12.second;
	}
	else{
		cout << clock24.second;
	}

	cout << "        *" << endl; // Clock border
	cout << "**************************     **************************" << endl; // Clock border
	cout << "Hold ESCAPE [ESC] key to edit time" << endl; // Prompts user to hold [ESC] button to edit time
}

// Method to display the edit clock options
void UserOptionsMenu(){

	// Prints the options menu for the user
	cout << "**************************" << endl;
	cout << "* 1 - Add One Hour       *" << endl;
	cout << "* 2 - Add One Minute     *" << endl;
	cout << "* 3 - Add One Second     *" << endl;
	cout << "* 4 - Exit Program       *" << endl;
	cout << "**************************" << endl;
}

// Method to utilize ESCAPE button as decision button
bool EditTime(short decisionKey){

	// Setting variable for byte range of the decision key
	const unsigned short pressedKey = 0x8000;

	// Checks if decisionKey is in range of 0x8000
	if (GetAsyncKeyState(decisionKey) & pressedKey){
		return true;
	}
	else{
		return false;
	}
}

int main()
{
	// Clock times set at 11:59:59(AM)
	_12HourClock _12ClockTimes(11, 59, 59);
	_24HourClock _24ClockTimes(11, 59, 59);
	ClockDisplay(_12ClockTimes, _24ClockTimes);

	// Loop to add one second to clocks until user presses ESC key
	// Starts looping as soon as program is started
	while(!EditTime(VK_ESCAPE)){
		Sleep(1000);
		_12ClockTimes.AddOneSecond();
		_24ClockTimes.AddOneSecond();
		ClockDisplay(_12ClockTimes, _24ClockTimes);
	}
	// While loop starts once user presses decision key [ESC]
	// Then the option menu will appear
	while(true){
		UserOptionsMenu();
		char userNum;
		cin >> userNum;

		switch(userNum){
			// If user presses 1 - Will add 1 hour to both clocks
			case '1':
				_12ClockTimes.AddOneHour();
				_24ClockTimes.AddOneHour();
				// Returns to loop to add one second
				while(!EditTime(VK_ESCAPE)){
					Sleep(1000);
					_12ClockTimes.AddOneSecond();
					_24ClockTimes.AddOneSecond();
					ClockDisplay(_12ClockTimes, _24ClockTimes);
				}
				break;

			case '2':
				// If user presses 2 - Will add 1 minute to both clocks
				_12ClockTimes.AddOneMinute();
				_24ClockTimes.AddOneMinute();
				// Returns to loop to add one second
				while(!EditTime(VK_ESCAPE)){
					Sleep(1000);
					_12ClockTimes.AddOneSecond();
					_24ClockTimes.AddOneSecond();
					ClockDisplay(_12ClockTimes, _24ClockTimes);
				}
				break;

			case '3':
				// If user presses 3 - Will add 1 second to both clocks
				_12ClockTimes.AddOneSecond();
				_24ClockTimes.AddOneSecond();
				// Returns to loop to add one second
				while(!EditTime(VK_ESCAPE)){
					Sleep(1000);
					_12ClockTimes.AddOneSecond();
					_24ClockTimes.AddOneSecond();
					ClockDisplay(_12ClockTimes, _24ClockTimes);
				}
				break;

			case '4':
				// If user presses 4 - ends program, clocks stop running
				cout << "Program ended.";
				exit(1);
				break;

			default:
				// If user presses anything other than 1,2,3,4 - Will prompt user to input again
				cout << "Invalid input. Please try again." << endl;
				break;
		}
	}

return 0;
}


