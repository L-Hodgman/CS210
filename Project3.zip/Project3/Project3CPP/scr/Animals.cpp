/*
 * Animals.cpp
 *
 *  Created on: Oct 11, 2020
 *      Author: Elizabeth Hodgman
 */
#include "Animals.h"

//Animal constructor and deconstructor
Animal::Animal(int trackNumber, string animalName, string animalType, string animalSubType, int birthType){
	this->trackNumber = trackNumber;
	this->animalName = animalName;
	this->animalType = animalType;
	this->animalSubType = animalSubType;
	this->birthType = birthType;
}
Animal::~Animal(){
}

// Mammal inherits Animal - constructor and deconstructor
Mammal::Mammal(int trackNumber, string animalName, string animalType, string animalSubType, int Nurse):Animal(trackNumber, animalName, animalType, animalSubType, Nurse){
	this->Nurse = Nurse;
}
Mammal::~Mammal(){
}

// Oviparous constructor and deconstructor
Oviparous::Oviparous(int trackNumber, string animalName, string animalType, string animalSubType, int eggs):Animal(trackNumber, animalName, animalType, animalSubType, eggs){
	this->eggs = eggs;
}
Oviparous::~Oviparous(){
}


