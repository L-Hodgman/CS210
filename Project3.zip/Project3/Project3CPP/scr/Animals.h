/*
 * Animals.h
 *
 *  Created on: Oct 11, 2020
 *  Author: Elizabeth Hodgman
*/

#ifndef ANIMALS_H_
#define ANIMALS_H_

#include <iostream>
using namespace std;

class Animal {
public:
	Animal(int trackNumber, string animalName, string animalType, string animalSubType, int birthType);
	virtual ~Animal();
	int trackNumber;
	string animalName;
	string animalType;
	string animalSubType;
	int birthType;
};

class Mammal : public Animal {
public:
	Mammal(int trackNumber, string animalName, string animalType, string animalSubType, int Nurse);
	virtual ~Mammal();
	int Nurse;
};

class Oviparous : public Animal {
public:
	Oviparous(int trackNumber, string animalName, string animalType, string animalSubType, int eggs);
	virtual ~Oviparous();
	int eggs;
};

#endif /* ANIMALS_H_ */
