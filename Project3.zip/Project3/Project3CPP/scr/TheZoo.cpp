/*
 * TheZoo.cpp
 *
 *  Created on: Oct 8, 2020
 *      Author: Elizabeth Hodgman
 */
#include <iomanip>
#include <iostream>
#include <stdlib.h>
#include <jni.h>
#include <vector>
#include <fstream>
#include <sstream>
#include <algorithm>

#include "Animals.h"
vector <string> animalList;
string trackNumber;
string animalName;
string animalType;
string animalSubType;
string eggs;
string Nurse;
string data;

using namespace std;


void GenerateData()               //DO NOT TOUCH CODE IN THIS METHOD
{
     JavaVM *jvm;                      // Pointer to the JVM (Java Virtual Machine)
     JNIEnv *env;                      // Pointer to native interface
                                                              //================== prepare loading of Java VM ============================
     JavaVMInitArgs vm_args;                        // Initialization arguments
     JavaVMOption* options = new JavaVMOption[1];   // JVM invocation options
     options[0].optionString = (char*) "-Djava.class.path=U:/Project3Java/bin";   // where to find java .class
     vm_args.version = JNI_VERSION_1_6;             // minimum Java version
     vm_args.nOptions = 1;                          // number of options
     vm_args.options = options;
     vm_args.ignoreUnrecognized = false;     // invalid options make the JVM init fail
                                                                          //=============== load and initialize Java VM and JNI interface =============
     jint rc = JNI_CreateJavaVM(&jvm, (void**)&env, &vm_args);  // YES !!
     delete options;    // we then no longer need the initialisation options.
     if (rc != JNI_OK) {
            // TO DO: error processing...
            cin.get();
            exit(EXIT_FAILURE);
     }
     //=============== Display JVM version =======================================
     cout << "JVM load succeeded: Version ";
     jint ver = env->GetVersion();
     cout << ((ver >> 16) & 0x0f) << "." << (ver & 0x0f) << endl;

     jclass cls2 = env->FindClass("ZooFileWriter");  // try to find the class
     if (cls2 == nullptr) {
            cerr << "ERROR: class not found !";
     }
     else {                                  // if class found, continue
            cout << "Class MyTest found" << endl;
            jmethodID mid = env->GetStaticMethodID(cls2, "createZooFile", "()V");  // find method
            if (mid == nullptr)
                   cerr << "ERROR: method void createZooFile() not found !" << endl;
            else {
                   env->CallStaticVoidMethod(cls2, mid);                      // call method
                   cout << endl;
            }
     }


     jvm->DestroyJavaVM();
     cin.get();
}

//
// Method to check if input is a number
bool isNumber(string s) { // Checks to see if input in AddAnimal and DeleteRecord is a number
    if(s.size()==0) return false;
    for(unsigned int i=0;i<s.size();i++) {
        if((s[i]>='0' && s[i]<='9')==false) {
            return false;
        }
    }
    return true;
}

//
// Method to display animals in vector
void DisplayAnimals(){
	cout << right << setw(6) << "Track# "; // Display Header
	cout << left << setw(15) << "Name";
	cout << left << setw(15) << "Type";
	cout << left << setw(15) << "Sub-type";
	cout << left << setw(1) << "Eggs ";
	cout << left << setw(1) << "Nurse" << endl;

	if(animalList.size() > 0){
		sort(animalList.begin(), animalList.end()); // Sort list by number
		for(unsigned int i = 0; i < animalList.size(); i++){
			cout << animalList.at(i) << endl; // Lists each line in vector
			}
		}

	else if(animalList.size() == 0){ // If no animals in vector
		cout << "No animals in list" << endl;
		cout << "Make Sure Saved Data is Loaded (Option [1]) or Add A New Record (Option [4])" << endl; // Prompts user to make sure saved data is loaded
	}

}

//
// Method to add animal record
void AddAnimal(){

	char userKey;

	cout << "Enter Tracking Number: ";
	cin >> trackNumber;
	while((!isNumber(trackNumber)) || (trackNumber.length() > 6)){ // Checks if input is number and within 6 digit limit
		cout << "Error: Enter A 6 Digit or Less Number" << endl;
		cout << "Enter Tracking Number: ";
		cin >> trackNumber;
	}
	trackNumber.insert(trackNumber.begin(), 6 - trackNumber.length(), '0'); // 6 figure number - fills space with 0
	trackNumber = trackNumber + " "; // Adds space after track number for proper spacing in output

	cout << "Enter Animal Name: "; // Input Name
	cin >> animalName;
	animalName[0] = toupper(animalName[0]); // Capitalizes Name
	animalName.insert(animalName.end(), 15 - animalName.length(), ' '); // Length 15 spaces - fills extra with spaces

	cout << "Enter Animal Type (Mammal or Oviparous): "; // Input Type
	cin  >> setw(15) >> animalType;
	animalType[0] = toupper(animalType[0]); // Capitalizes Type

	while((animalType != "Mammal") && (animalType != "Oviparous")){ // Checking for Type validation
		cout << "Error: Animal Type must be Mammal or Oviparous" << endl;
		cout << "Enter Animal Type (Mammal or Oviparous): ";
		cin >> setw(15) >> animalType;
		animalType[0] = toupper(animalType[0]);
	}

	if(animalType == "Mammal"){ // Checking for Sub-Type validation
		cout << "Enter Animal Sub-Type(Whale, Bat, Sealion): ";
		cin >> setw(15) >> animalSubType;
		animalSubType[0] = toupper(animalSubType[0]); // Capitalizes Sub-Type
		while((animalSubType != "Whale") && (animalSubType != "Bat") && (animalSubType != "Sealion")){
			cout << "Error: Sub-type Must Be Whale, Bat, or Sealion" << endl;
			cout << "Enter Animal Sub-Type(Whale, Bat, Sealion): ";
			cin >> setw(15) >> animalSubType;
			animalSubType[0] = toupper(animalSubType[0]); // Recapitalizes Sub-Type for loop
		}
	}
	else if(animalType == "Oviparous"){ // Checking for Sub-Type validation
		cout << "Enter Animal Sub-Type(Crocodile, Goose, Pelican): ";
		cin >> setw(15) >> animalSubType;
		animalSubType[0] = toupper(animalSubType[0]);
		while((animalSubType != "Crocodile") && (animalSubType != "Goose") && (animalSubType != "Pelican")){
			cout << "Error: Sub-type Must Be Crocodile, Goose, or Pelican" << endl;
			cout << "Enter Animal Sub-Type(Crocodile, Goose, Pelican): ";
			cin >> setw(15) >> animalSubType;
			animalSubType[0] = toupper(animalSubType[0]); // Recapitalizes Sub-Type for loop
		}
	}
	animalSubType.insert(animalSubType.end(), 15 - animalSubType.length(), ' '); // Length of Sub-Type 15 - Fills with spaces
	animalSubType = animalSubType + " "; // Add space after Sub-Type for output

	if(animalType == "Mammal"){ // If Type = Mammal
		eggs = "0"; // Eggs automatically 0 because they nurse live young

		cout << "Select: 1 - Nursing | 0 - Not Nursing: ";
		cin >> setw(1) >> Nurse;


		while((Nurse != "1") && (Nurse != "0")){ // Check Nurse input validation
			cout << "Error: Must Enter 1 or 0" << endl;
			cout << "Select: 1 - Nursing | 0 - Not Nursing: ";
			cin >> setw(1) >> Nurse;
		}
		cout << endl;
	}
	else if(animalType == "Oviparous"){ // If Type = Oviparous
		Nurse = "0"; // Nurse automatically 0 because they lay eggs

		cout << "Enter Number of Eggs: ";
		cin >> setw(1) >> eggs;
		while(!isNumber(eggs)){ // If input is not a number
			cout << "Error: A Number Was Not Entered" << endl;
			cout << "Enter Number of Eggs: ";
			cin >> setw(1) >> eggs;
		}
	}
	eggs = eggs + "     "; // Added space between Eggs and Nurse for output
	animalType.insert(animalType.end(), 15 - animalType.length(), ' ');
	cout << endl;

	cout << right << setw(6) << "Track# "; // Validating and showing user input for user to save
	cout << left << setw(15) << "Name";
	cout << left << setw(15) << "Type";
	cout << left << setw(15) << "Sub-type";
	cout << left << setw(2) << "Eggs ";
	cout << left << setw(1) << "Nurse" << endl;
	cout << trackNumber << animalName << animalType << animalSubType << eggs << Nurse << endl;
	cout << "Do you want to save this data?" << endl;
	cout << "Press: 'Y' for Yes - 'N' for No: ";
	cin >> userKey;
	userKey = toupper(userKey); // userKey capitalize

	while((userKey != 'Y') && (userKey != 'N')){ // Error if userKey is not 'Y' or 'N'
		cout << "Error: Enter 'Y' or 'N'" << endl;
		cout << "Do you want to save this data?" << endl;
		cout << "Press: 'Y' for Yes - 'N' for No: ";
		cin >> userKey;
		userKey = toupper(userKey);
	}

	if(userKey == 'Y'){ // If info saved

			data = trackNumber +  animalName + animalType + animalSubType + eggs + Nurse; // Adds all user input to data
			animalList.push_back(data); // Adds data to vector

			cout << "Animal successfully added" << endl;
	}
	else if(userKey == 'N'){ // If info not saved
		cout << "Animal not saved" << endl;
	}

}

//
// Method to remove/delete animal record
void RemoveAnimal(){
			if(animalList.size() == 0){ // If no animals are in record
				cout << "There Are No Animals To Delete" << endl; // Prompts user to make sure saved animals are loaded in
				cout << "Please Make Sure Your Saved Animal Records Are Loaded(Option [1])" << endl;
			}
			else if(animalList.size() > 0){ // Continues to record deletion if there are animals in vector
			string animalName;
			cout << "Enter Animal Name to Delete Record or Enter X to Cancel: ";
			cin >> animalName;
			animalName[0] = toupper(animalName[0]); // Capitalizes input if user does not capitalize when typing
			while(isNumber(animalName)){ // User can not input number for name
				cout << "Error: Name Not Entered" << endl;
				cout << "Enter Animal Name to Delete Record of Enter X to Cancel: ";
				cin >> animalName;
				animalName[0] = toupper(animalName[0]);
			}
			if((animalName != "x") && (animalName != "X")){ // Continues to deleting record if user does not enter X

				cout << "Are you sure you want to delete this animal record?" << endl;
				cout << "Please press 'Y' to continue or 'N' to cancel" << endl;

				char userKey;
				cin >> userKey;
				userKey = toupper(userKey);

				switch(userKey){
				case 'Y': // If user enters Y - Removes whole string if name is found
						  // If inputed name not in list - Nothing will be deleted
					animalList.erase(remove_if(animalList.begin(), animalList.end(),[&](const std::string &s){return s.find(animalName) != std::string::npos;}),animalList.end());
					cout << "Animal deleted" << endl;
					return;
				case 'N': // If user enter N - Does not delete string
					cout << "Animal not deleted" << endl;
					return;
				default: // If user does not enter Y or N - returns to beginning of RemoveAnimal method
					cout << "Invalid input please try again" << endl;
					RemoveAnimal();
				}
				}
			else if((animalName == "x") || (animalName == "X")){ // Returns to main display menu if user cancels deletion
				return;
			}
		}
}

//
// Method to load data in file to the animal record vector
void LoadDataFromFile(){
	string file = "zoodata.txt";
	ifstream file1(file.c_str());

	if(!file1.is_open() || file1.fail()){ // If file does not open properly
		file1.close();
		cout << "Cannot open file" << endl;
	}
	else{ // If file opens
		string line1;
		while(getline(file1, line1)){
			if(line1.size()>0){
				animalList.push_back(line1); // Takes contents out of file and puts into vector
			}
		}
		file1.close();
		cout << "Load Complete" << endl;
	}
}

//
// Method to save records in vector to the file
void SaveDataToFile(){
	ofstream javaFile("zoodata.txt", std::ios::out | std::ios::trunc); // Opens file and clears its contents

	if(javaFile.fail()){ // If file does not open
		cout << "File Opening Failed" << endl;
	}
	else{ // If file opens
		for(unsigned int i = 0; i < animalList.size(); ++i){
				javaFile << animalList.at(i) << "\n"; // Loops through vector and puts its contents into file to save
			}
			javaFile.close();
			cout << "Save successful" << endl;
		}
}

//
// Method to direct user input
void userSelection(char userKey){
	switch(userKey){
		case '1': // Option [1]
			LoadDataFromFile();
			break;
		case '2': // Option [2] calls Java.FileWriter
			GenerateData();
			cout << "Select Load Animal Data (Option [1]) to Add Animal to List" << endl; // User has to select load for the animal to be added to list
			break;
		case '3': // Option [3] displays all animals currently in list
			DisplayAnimals();
			break;
		case '4': // Option [4] lets user to input and add new animal records
			AddAnimal();
			break;
		case '5': // Option [5] lets user choose what record to delete
			RemoveAnimal();
			break;
		case '6': // Option [6] saves current animal records - if the user stops the program, the records can be loaded back when it is started again
			SaveDataToFile();
			break;
		case '7': // Stops program
			cout << "Goodbye";
			exit(1);
		default: // Error if input is not 1, 2, 3, 4, 5, 6, 7
			cout << "Error: Please try again" << endl;
			return;
	}
}

//
// Method to display user menu
void DisplayMenu(){

	cout << "---------------------------" << endl;
	cout << "| [1] Load Animal Data    |" << endl;
	cout << "| [2] Generate Data       |" << endl;
	cout << "| [3] Display Animal Data |" << endl;
	cout << "| [4] Add Record          |" << endl;
	cout << "| [5] Delete Record       |" << endl;
	cout << "| [6] Save Animal Data    |" << endl;
	cout << "| [7] Quit                |" << endl;
	cout << "---------------------------" << endl;

}

//
// MAIN
int main(){
		char userKey;
	while(true){ // Constantly loops after every method
			DisplayMenu(); // Displays user choice menu
			cin >> userKey; // User input for userSelecton method
			userSelection(userKey);
		}
	return 1;
}



